from odoo import models, fields, api

class Articulo(models.Model):
    _name = 'tienda.articulo'
    nombre = fields.Char('Nombre', requiered=True)
    descripcion = fields.Char('Descripcion')
    precio = fields.Integer('Precio')
    codProv = fields.Many2one('tienda.proveedor', 'Codigo Proveedor')
    codArt = fields.Integer('Codigo articulo', requiered=True)

    def name_get(self):
        res=[]
        for record in self:
            name = record.codArt
            res.append((record.id, name))
        return res
