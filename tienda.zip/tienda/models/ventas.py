from odoo import models, fields, api

class Ventas(models.Model):
    _name = 'tienda.ventas'
    codProv = fields.Many2one('tienda.proveedor', 'Proveedor')
    codArt = fields.Many2one('tienda.articulo', 'Articulo')
    fecha = fields.Date(string='Fecha', default=lambda s: fields.Date.context_today(s))


