from odoo import models, fields, api

class Proveedor(models.Model):
    _name = 'tienda.proveedor'
    nombre = fields.Char('Nombre', required=True)
    codProv = fields.Integer('Codigo Proveedor', required=True)
    pais = fields.Char('Pais', requiered=True)

    def name_get(self):
        res=[]
        for record in self:
            name = record.nombre
            res.append((record.id, name))
        return res





