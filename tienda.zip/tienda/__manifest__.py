{
    'name' : 'tienda',
    'description' : 'Tienda odoo',
    'author' : 'Rafa Cardona',
    'depends' : ['base'],
    'application' : True,
    'data' : ['views/proveedor.xml', 'views/articulo.xml', 'views/ventas.xml']

}